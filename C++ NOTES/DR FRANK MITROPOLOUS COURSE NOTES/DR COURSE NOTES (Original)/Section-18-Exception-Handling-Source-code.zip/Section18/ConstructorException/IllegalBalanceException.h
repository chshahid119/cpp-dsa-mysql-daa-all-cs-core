#ifndef __ILLEGAL_BALANCE_EXCEPTION_H__
#define __ILLEGAL_BALANCE_EXCEPTION_H__

class IllegalBalanceException
{
public:
    IllegalBalanceException() = default;
    ~IllegalBalanceException() = default;
};

#endif // __ILLEGAL_BALANCE_EXCEPTION_H__
